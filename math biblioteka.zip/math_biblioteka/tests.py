# tests.py - Pārbauda vai visi 15 faili strādā

import subprocess
import sys
import os

faili = [
    "f01_kvadratsakne.py",
    "f02_kapinajums.py",
    "f03_noapalot_leju.py",
    "f04_noapalot_augsu.py",
    "f05_pi.py",
    "f06_faktorials.py",
    "f07_logaritms.py",
    "f08_trigonometrija.py",
    "f09_gradi_radiani.py",
    "f10_lielakais_dalitajs.py",
    "f11_absolutais.py",
    "f12_eilera.py",
    "f13_hipotenūza.py",
    "f14_parbaudes.py",
    "f15_kombinacijas.py",
]

stradā = 0
kļūda = 0

print("Pārbaudu visus failus...\n")

for fails in faili:
    cels = os.path.join("funkcijas", fails)

    if not os.path.exists(cels):
        print(f"NAV ATRASTS: {fails}")
        kļūda += 1
        continue

    rezultats = subprocess.run(
        [sys.executable, cels],
        capture_output=True,
        text=True,
        timeout=5
    )

    if rezultats.returncode == 0:
        print(f"OK: {fails}")
        stradā += 1
    else:
        print(f"KĻŪDA: {fails}")
        print(f"  {rezultats.stderr.strip()}")
        kļūda += 1

print(f"\nStrādā: {stradā}/15")
print(f"Kļūdas: {kļūda}/15")
